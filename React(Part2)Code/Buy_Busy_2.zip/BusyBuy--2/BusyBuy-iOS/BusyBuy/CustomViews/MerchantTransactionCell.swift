//
//  MerchantTransactionCell.swift
//  BusyBuy
//
//  Created by Prasad Pamidi on 10/25/15.
//  Copyright © 2015 Self. All rights reserved.
//

import UIKit

class MerchantTransactionCell: UITableViewCell {
    
    @IBOutlet weak var lbl_transactionAmnt: UILabel!
    @IBOutlet weak var imgVw_transactionStatus: UIImageView!
    @IBOutlet weak var lbl_merchantName: UILabel!
    @IBOutlet weak var lbl_transactionDetails: UILabel!
    @IBOutlet weak var lbl_transaction_status: UILabel!
}
