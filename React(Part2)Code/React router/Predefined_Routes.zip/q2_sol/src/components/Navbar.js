export const Navbar = () => {
  return (
    <div className="navbar">
      <img
        src="https://cdn-icons-png.flaticon.com/512/3176/3176363.png"
        alt="logo"
      />
    </div>
  );
};
